#include "win32_handmade.h"
#include "handmade.h"


// Globals
static bool g_running;
static Win32BackBuffer g_back_buffer;
static Win32Audio g_audio;
static LARGE_INTEGER g_performance_freq;


// =====================================================
// HOT RELOADING
// =====================================================
inline static FILETIME
win32_get_file_attr(void)
{
    WIN32_FILE_ATTRIBUTE_DATA file_data {};
    int32_t res = GetFileAttributesExA("handmade.dll", GetFileExInfoStandard, &file_data);
    return file_data.ftLastWriteTime;
}

static void
win32_load_game_code(Win32LoadedGameCode &game)
{
    game.last_write_time = win32_get_file_attr();

    if (!game.is_stable) {
        int32_t result = CopyFile("handmade.dll", "game_handmade.dll", FALSE);
        game.dll_handle = LoadLibrary("game_handmade.dll");

        if (game.dll_handle) {
            game.fill_sound_output_buffer = (
                (ptr_game_fill_sound_output_buffer)GetProcAddress(game.dll_handle, "game_fill_sound_output_buffer")
            );
            game.update_and_render = (
                (ptr_game_update_and_render)GetProcAddress(game.dll_handle, "game_update_and_render")
            );

            game.is_stable = true;
        }
    }
}

static void
win32_unload_game_code(Win32LoadedGameCode &game)
{
    FreeLibrary(game.dll_handle);

    game.fill_sound_output_buffer = nullptr;
    game.update_and_render = nullptr;
    game.dll_handle = nullptr;

    game.is_stable = false;
}

// =============================================================
// FILE I/O
// =============================================================
void*
DEBUGplatform_read_entire_file(const char *filename)
{
    void *result = nullptr;
    LARGE_INTEGER file_size {};
    HANDLE file_handle = CreateFile(filename, GENERIC_READ, 0,
        NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (file_handle) {
        if(GetFileSizeEx(file_handle, &file_size)) {
            ASSERT(file_size.QuadPart < MAX_UINT32)
            unsigned long trunc_file_size = static_cast<unsigned long>(file_size.QuadPart);
            result = VirtualAlloc(NULL, trunc_file_size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
            if (result) {
                unsigned long bytes_read {};
                if (ReadFile(file_handle, result, trunc_file_size, &bytes_read, NULL) &&
                    trunc_file_size == bytes_read)
                {} else {
                    DEBUGplatform_free_file(result);
                    result = nullptr;
                }
            }
        }
    }

    CloseHandle(file_handle);

    return result;
}

void
DEBUGplatform_free_file(void *memory)
{
    VirtualFree(memory, 0, MEM_RELEASE);
}

// ===========================================================
// INPUT RECORDING AND PLAYBACK
// ===========================================================
static void
win32_begin_recording(Win32State &state)
{
    uint64_t input_size = MEBIBYTES(4);
    state.recording.is_recording = true;
    state.recording.total_size = state.game_memory_size + input_size;
    state.recording.memory = VirtualAlloc(NULL, state.recording.total_size,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    // Maybe only write the actual amount of memory thats stored
    RtlCopyMemory(state.recording.memory, state.game_memory_block, state.game_memory_size);
}

static void
win32_end_recording(Win32State &state)
{
    state.recording.is_recording = false;
}

// Playback the game state
static void
win32_begin_playback(Win32State &state)
{
    state.recording.is_playbacking = true;
    state.recording.curr_input = 0;
    RtlCopyMemory(state.game_memory_block, state.recording.memory, state.game_memory_size);
}

static void
win32_end_playback(Win32State &state)
{
    state.recording.is_playbacking = false;
    state.recording.input_count = 0;
    state.recording.curr_input = 0;
    state.recording.total_size = 0;
    // Copy mem over to game state if you want to start at frame 0 after ending
    VirtualFree(state.recording.memory, 0, MEM_RELEASE);
    state.recording.memory = nullptr;
}

static void
win32_record_input(Win32State &state, const GameInput *input)
{
    void *base_addr = (void *)(
        (uint8_t*)state.recording.memory + state.game_memory_size +
        sizeof(*input) * state.recording.input_count);

    RtlCopyMemory(base_addr, input, sizeof(*input));
    state.recording.input_count++;
}

static void
win32_playback_input(Win32State &state, GameInput *input)
{
    // Need to rewind the game state and the input
    if (state.recording.curr_input >= state.recording.input_count) {
        RtlCopyMemory(state.game_memory_block, state.recording.memory,
            state.game_memory_size);
        state.recording.curr_input = 0;
    }

    void *base_addr = (void*)((uint8_t*)state.recording.memory +
        state.game_memory_size + (sizeof(*input) * state.recording.curr_input));

    *input = *(GameInput*)base_addr;
    state.recording.curr_input++;
}

// ==============================================
// INPUT PROCESSING
// ==============================================
static void
win32_process_keyboard_event(GameButtonState &button, bool is_down)
{
    button.ended_down = is_down;
    ++button.half_transition_state;
}

// ===================================================================================
// NOT NEEDED ANYMORE
// ===================================================================================
static void
win32_debug_draw_audio_frame(uint32_t frame_pixel_col, int32_t top, int32_t bottom)
{
    uint8_t *pixel_addr = ((uint8_t*)g_back_buffer.bitmap_mem + // base
        (frame_pixel_col * g_back_buffer.bytes_per_pixel) + // column
        (top * g_back_buffer.bitmap_pitch)); // row

    for (int32_t pixel_index {top}; pixel_index < bottom; ++pixel_index) {
        uint32_t *pixel = (uint32_t*)pixel_addr;
        *pixel = 0xFFFFFFFF;
        pixel_addr += g_back_buffer.bitmap_pitch;
    }
}

static void
win32_debug_display_audio(uint32_t *play_cursors, uint32_t play_cursors_count,
    GameSoundOutput &sound_output, float target_seconds_per_frame)
{
    uint32_t ypad = 16;
    uint32_t xpad = 16;
    uint32_t top = ypad;
    uint32_t bottom = g_back_buffer.bitmap_height - ypad;
    // audio frames to pixels ratio to map into back_buffer
    float coefficient = (float)g_back_buffer.bitmap_width / g_audio.buffer_frame_capacity;

    for (uint32_t play_cursor_index {}; play_cursor_index < play_cursors_count; ++play_cursor_index) {
        uint32_t frame_pixel_col = (uint32_t)(coefficient * play_cursors[play_cursor_index]);
        win32_debug_draw_audio_frame(frame_pixel_col, top, bottom);
    }
}
// ==========================================================================================
// ==========================================================================================
// ==========================================================================================

static void
win32_display_buffer(HDC dest_device_context, const Win32BackBuffer &buffer, int win_height, int win_width)
{
    int32_t back_buffer_offset_x = 10;
    int32_t back_buffer_offset_y = 10;

    // PatBlt just clears the parts our bitmap is not writing to in the window client
    // PatBlt(dest_device_context, 0, 0, win_width, back_buffer_offset_y, BLACKNESS);
    // PatBlt(dest_device_context, 0, 0, back_buffer_offset_x, win_height, BLACKNESS);
    PatBlt(dest_device_context, buffer.bitmap_width, 0, win_width - buffer.bitmap_width, win_height, BLACKNESS);
    PatBlt(dest_device_context, 0, buffer.bitmap_height, win_width, win_height - buffer.bitmap_height, BLACKNESS);

    StretchDIBits(dest_device_context, 0, 0, buffer.bitmap_width, buffer.bitmap_height, 0, 0,
                buffer.bitmap_width, buffer.bitmap_height, buffer.bitmap_mem,
                &buffer.bitmap_info, DIB_RGB_COLORS, SRCCOPY);
}

// ==============================================
// WINDOW UTILS
// ==============================================
static Win32WinDimensions
win32_get_win_dimensions(HWND win_handle)
{
    Win32WinDimensions res {};
    RECT client_rect {};

    GetClientRect(win_handle, &client_rect);
    res.width = client_rect.right - client_rect.left;
    res.height = client_rect.bottom - client_rect.top;

    return res;
}

static void
win32_resize_DIB_section(Win32BackBuffer &buffer, int win_height, int win_width)
{
    if (buffer.bitmap_mem) {
        VirtualFree(buffer.bitmap_mem, 0, MEM_RELEASE);
    }

    buffer.bitmap_height = win_height;
    buffer.bitmap_width = win_width;
    buffer.bytes_per_pixel = 4;
    buffer.bitmap_pitch = buffer.bitmap_width * buffer.bytes_per_pixel;
    buffer.bitmap_info.bmiHeader.biSize = sizeof(buffer.bitmap_info.bmiHeader);
    buffer.bitmap_info.bmiHeader.biWidth = buffer.bitmap_width;
    buffer.bitmap_info.bmiHeader.biHeight = -buffer.bitmap_height; // Top-down
    buffer.bitmap_info.bmiHeader.biPlanes = 1;
    buffer.bitmap_info.bmiHeader.biBitCount = 32;
    buffer.bitmap_info.bmiHeader.biCompression = BI_RGB;

    int bitmap_size {buffer.bitmap_width * buffer.bitmap_height * buffer.bytes_per_pixel};
    buffer.bitmap_mem = VirtualAlloc(NULL, bitmap_size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
}

LRESULT
win32_window_proc(HWND win_handle, UINT msg, WPARAM wparam, LPARAM lparam)
{
    LRESULT res {};

    switch (msg) {
    case WM_SIZE:
    {
    } break;
    case WM_DESTROY:
    {
    } break;
    case WM_CLOSE:
    {
        g_running = false;
    } break;
    case WM_ACTIVATEAPP:
    {

    } break;
    case WM_KEYDOWN:
    case WM_KEYUP:
    case WM_SYSKEYDOWN:
    case WM_SYSKEYUP: {
      ASSERT(!"INPUT CAME FROM SOMEWHERE ELSE")
    } break;
    case WM_PAINT:
    {
        PAINTSTRUCT paint_area {};
        HDC device_context = BeginPaint(win_handle, &paint_area);
        int width {paint_area.rcPaint.right - paint_area.rcPaint.left};
        int height {paint_area.rcPaint.bottom - paint_area.rcPaint.top};

        Win32WinDimensions dimensions {win32_get_win_dimensions(win_handle)};
        win32_display_buffer(device_context, g_back_buffer, height, width);
        EndPaint(win_handle, &paint_area);
    } break;
    default:
    {
        res = DefWindowProc(win_handle, msg, wparam, lparam);
    } break;
    }

    return res;
}

// ============================================
// MAIN ENTRY
// ============================================
int WINAPI
WinMain(HINSTANCE instance, HINSTANCE prev_instance, PSTR cmd_line, int cmd_show)
{
    WNDCLASS window_class {};
    window_class.style = CS_HREDRAW | CS_VREDRAW; // Repaint the whole window instead of just the new section
    window_class.lpfnWndProc = win32_window_proc;
    window_class.hInstance = instance;
    window_class.lpszClassName = "HandmadeWindowClass";
    win32_resize_DIB_section(g_back_buffer, 540, 960);

    QueryPerformanceFrequency(&g_performance_freq);

    constexpr uint32_t hns_wasapi_buffer_duration = 100000;

    if (RegisterClass(&window_class)) {
        HWND window_handle = CreateWindowEx(
            0, window_class.lpszClassName, "Handmade Hero",
            WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
            CW_USEDEFAULT, CW_USEDEFAULT, 0, 0, instance, 0);

        if (window_handle) {
            int32_t monitor_refresh_hz = 60;
            HDC dc = GetDC(window_handle);
            int32_t win32_monitor_refresh_rate = GetDeviceCaps(dc, VREFRESH);
            ReleaseDC(window_handle, dc);

            if (win32_monitor_refresh_rate > 1) {
                monitor_refresh_hz = win32_monitor_refresh_rate;
            }

            float game_refresh_hz = monitor_refresh_hz / 2.0f;
            float target_seconds_per_frame = 1.0f / game_refresh_hz;

            win32_init_wasapi(&g_audio, 0, hns_wasapi_buffer_duration);
            g_audio.client->Start();

            g_running = true;
            Win32State win32_state {};

            // NOTE: Might have to move if we ever allow audio endpoint to change
            GameSoundOutput sound_output {};
            sound_output.channel_count = static_cast<uint8_t>(g_audio.wave_fmt->nChannels);
            sound_output.tone_hz = 256;
            sound_output.running_frame_index = 0;
            // VOLUME IS OFF change to .3 to turn it on
            sound_output.volume = 0.0f;
            sound_output.samples_per_sec = g_audio.wave_fmt->nSamplesPerSec;
            sound_output.frame_size = g_audio.wave_fmt->nBlockAlign;

            // Memory allocation
            void *base_address = NULL;

#ifdef BUILD_INTERNAL
            // we always want the memory to start here for dev builds
            base_address = reinterpret_cast<void *>(TEBIBYTES(2));
#endif

            constexpr uint64_t persistent_mem_size = MEBIBYTES(64);
            constexpr uint64_t transient_mem_size = GIBIBYTES(1);
            win32_state.game_memory_size = persistent_mem_size + transient_mem_size;
            win32_state.game_memory_block = VirtualAlloc(base_address, win32_state.game_memory_size,
                           MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

            GameMemory memory {};
            memory.persistent_storage_size = persistent_mem_size;
            memory.transient_storage_size = transient_mem_size;
            memory.persistent_storage = win32_state.game_memory_block;
            memory.transient_storage = reinterpret_cast<uint8_t*>(memory.persistent_storage) +
                memory.persistent_storage_size;

            if (!memory.persistent_storage || !memory.transient_storage) {
                return 0 ;
            }

            memory.read_file_func = DEBUGplatform_read_entire_file;
            memory.free_file_func = DEBUGplatform_free_file;

            GameInput input[2] {};
            GameInput *new_input = &input[0];
            GameInput *old_input = &input[1];

            // we can also add the cpu clock cycles with __rdtsc()
            LARGE_INTEGER last_counts;
            QueryPerformanceCounter(&last_counts);

            Win32LoadedGameCode game {};
            win32_load_game_code(game);

            // 1 iteration = 1 frame
            while (g_running) {
#ifdef BUILD_INTERNAL
                // DLL LOADING based on last write
                FILETIME curr_time = win32_get_file_attr();
                if (CompareFileTime(&curr_time, &game.last_write_time) != 0) {
                    win32_unload_game_code(game);
                    win32_load_game_code(game);
                }
#endif // BUILD_INTERNAL

                GameControllerInput *new_keyboard = &new_input->controllers[0];
                GameControllerInput *old_keyboard = &old_input->controllers[0];
                new_input->target_seconds_per_frame = target_seconds_per_frame;

                for (uint32_t button_i {}; button_i < ARRAY_SIZE(new_keyboard->Input.buttons_array); ++button_i) {
                    new_keyboard->Input.buttons_array[button_i].ended_down =
                        old_keyboard->Input.buttons_array[button_i].ended_down;
                }
/*
                POINT mouse_pos {};
                GetCursorPos(&mouse_pos);
                ScreenToClient(window_handle, &mouse_pos);
                new_input->mouse_x = mouse_pos.x;
                new_input->mouse_y = mouse_pos.y;
*/
                MSG msg;
                while (PeekMessage(&msg, window_handle, 0, 0, PM_REMOVE)) {
                    if (msg.message == WM_QUIT) {
                        g_running = false;
                    }

                    switch (msg.message) {
                    case WM_LBUTTONDOWN:
                    case WM_LBUTTONUP:
                    case WM_KEYDOWN:
                    case WM_KEYUP:
                    case WM_SYSKEYDOWN:
                    case WM_SYSKEYUP: {
                        uint64_t vk_code {msg.wParam};
                        bool prev_key_state {(msg.lParam & (1 << 30)) != 0};
                        bool is_key_down {(msg.lParam & (1 << 31)) == 0};

                        if (prev_key_state != is_key_down) {
                            if (vk_code == VK_LEFT) {
                            } else if (vk_code == VK_RIGHT) {
                            } else if (vk_code == VK_UP) {
                            } else if (vk_code == VK_DOWN) {
                            } else if (vk_code == VK_LBUTTON) {
                                win32_process_keyboard_event(new_input->mouse_buttons[0], is_key_down);
                            } else if (vk_code == VK_RBUTTON) {
                                win32_process_keyboard_event(new_input->mouse_buttons[1], is_key_down);
                            } else if (vk_code == 'W') {
                                win32_process_keyboard_event(new_keyboard->Input.Buttons.up, is_key_down);
                            } else if (vk_code == 'A') {
                                win32_process_keyboard_event(new_keyboard->Input.Buttons.left, is_key_down);
                            } else if (vk_code == 'S') {
                                win32_process_keyboard_event(new_keyboard->Input.Buttons.down, is_key_down);
                            } else if (vk_code == 'D') {
                                win32_process_keyboard_event(new_keyboard->Input.Buttons.right, is_key_down);
                            }
#ifdef BUILD_INTERNAL
                            else if (vk_code == 'L') {
                                if (is_key_down) {
                                    if (!win32_state.recording.is_recording) {
                                        win32_begin_recording(win32_state);
                                    } else {
                                        win32_end_recording(win32_state);
                                    }
                                }
                            } else if (vk_code == 'P') {
                                if (is_key_down) {
                                    if (!win32_state.recording.is_playbacking) {
                                        win32_begin_playback(win32_state);
                                    }
                                    else {
                                        win32_end_playback(win32_state);
                                        *new_input = {};
                                        *old_input = {};
                                    }
                                }
                            }
#endif // BUILD_INTERNAL
                        }
                    } break;
                    default:
                        TranslateMessage(&msg);
                        DispatchMessage(&msg);
                    }
                }

                ThreadContext thread {};

                GameBackBuffer game_buffer {};
                game_buffer.bitmap_mem = g_back_buffer.bitmap_mem;
                game_buffer.bitmap_height = g_back_buffer.bitmap_height;
                game_buffer.bitmap_width = g_back_buffer.bitmap_width;
                game_buffer.bytes_per_pixel = g_back_buffer.bytes_per_pixel;
                game_buffer.bitmap_pitch = g_back_buffer.bitmap_pitch;

                win32_audio_lock_buffer(g_audio, sound_output, g_audio.frame_count_bytes);
                game.fill_sound_output_buffer(thread, sound_output);

                uint32_t bytes_written = sound_output.region1_size + sound_output.region2_size;
                win32_audio_unlock_buffer(g_audio, bytes_written);

                if (win32_state.recording.is_recording) {
                    win32_record_input(win32_state, new_input);
                } else if (win32_state.recording.is_playbacking) {
                    win32_playback_input(win32_state, new_input);
                }

                game.update_and_render(thread, memory, new_input, game_buffer);

                // GAME INPUT SWITCH
                GameInput *temp = new_input;
                new_input = old_input;
                old_input = temp;

                // Performance tracking and Frame Rate Locking(Wall Clock or Real World Time)
                LARGE_INTEGER end_counts;
                QueryPerformanceCounter(&end_counts);

                int64_t elapsed_counts = end_counts.QuadPart - last_counts.QuadPart;
                float work_seconds_per_frame = ((float)elapsed_counts) / g_performance_freq.QuadPart;
                while (work_seconds_per_frame < target_seconds_per_frame) {
                    QueryPerformanceCounter(&end_counts);
                    elapsed_counts = end_counts.QuadPart - last_counts.QuadPart;
                    work_seconds_per_frame = ((float)elapsed_counts) / g_performance_freq.QuadPart;
                }

                QueryPerformanceCounter(&end_counts);
                last_counts = end_counts;

                Win32WinDimensions dimensions = win32_get_win_dimensions(window_handle);

                dc = GetDC(window_handle);
                win32_display_buffer(dc, g_back_buffer, dimensions.height, dimensions.width);
                ReleaseDC(window_handle, dc);

#ifdef BUILD_INTERNAL
/*
                {
                    float msecs_per_frame = (1000.0f * elapsed_counts) / g_performance_freq.QuadPart;
                    float fps = ((float)g_performance_freq.QuadPart) / elapsed_counts;
                    char msecs_per_frame_buff[256];
                    sprintf_s(msecs_per_frame_buff, "Milliseconds/frame: %.6f / %.6f FPS\n", msecs_per_frame, fps);
                    OutputDebugStringA(msecs_per_frame_buff);
                }
*/
#endif // BUILD_INTERNAL

            }
        }
    }

    return 0;
}
